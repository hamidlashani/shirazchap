<?php

return [
    'name' => 'Images'
];
